package com.conalryan.xml;

/**
 * A marker class the indicates the class was created from an XML instance
 *
 */
public interface XMLDomainObject {
}
