package com.conalryan.model;

import junit.framework.TestCase;
import org.junit.Test;

public class IntervalTest extends TestCase {

    @Test
    public void testIntervalCreation() { assertNotNull(Interval.WEEKLY); }

}