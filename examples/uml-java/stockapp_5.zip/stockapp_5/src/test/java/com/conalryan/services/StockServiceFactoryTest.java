package com.conalryan.services;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

/**
 * JUnit test for <CODE>StockServiceFactory</CODE>
 */
public class StockServiceFactoryTest {

    @Test
    public void testGetStockServiceInstance() {
        StockService stockService = StockServiceFactory.getStockServiceInstance();
        assertNotNull(stockService);
    }
}
