package com.conalryan.model;

import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * JUnit test for StockQuote class
 */
public class StockQuoteTest {

    private BigDecimal price;
    private Date date;
    private Calendar calendar;
    private String symbol;
    private StockQuote stockQuote;

    @Before
    public void setUp() {
        price = new BigDecimal(100);
        calendar = Calendar.getInstance();
        calendar.set(2015, Calendar.FEBRUARY, 23);
        symbol = "AAPL";
        stockQuote = new StockQuote(price, calendar.getTime(), symbol);
    }

    @Test
    public void testCreateObject() {
        assertNotNull(stockQuote);
    }

    @Test
    public void testGetPrice() {
        assertEquals("Share price is correct", price, stockQuote.getPrice());
    }

    @Test
    public void testGetDate() {
        assertEquals("Share date is correct", calendar.getTime(), stockQuote.getDate());
    }

    @Test
    public void testGetSymbol() {
        assertEquals("Symbol  is correct", symbol, stockQuote.getSymbol());
    }

    @Test
    public void testToString() {
        assertNotNull(stockQuote.toString());
    }

   @Test
    public void testEquals() {
       BigDecimal price2 = new BigDecimal(100);
       Calendar calendar2 = Calendar.getInstance();
       calendar2.set(2015, Calendar.FEBRUARY, 23);
       String symbol2 = "AAPL";
       StockQuote stockQuote2 = new StockQuote(price, calendar.getTime(), symbol);
       assertEquals("Stocks are equal", stockQuote, stockQuote2);
    }

    @Test
    public void testHashCode() {
        BigDecimal price2 = new BigDecimal(100);
        Calendar calendar2 = Calendar.getInstance();
        calendar2.set(2015, Calendar.FEBRUARY, 23);
        String symbol2 = "AAPL";
        StockQuote stockQuote2 = new StockQuote(price, calendar.getTime(), symbol);
        assertEquals("Stocks are equal", stockQuote.hashCode(), stockQuote2.hashCode());
    }
}

