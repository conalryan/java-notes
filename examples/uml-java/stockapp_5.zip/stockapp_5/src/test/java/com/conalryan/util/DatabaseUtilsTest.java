package com.conalryan.util;

import org.junit.Test;
import java.sql.Connection;
import static org.junit.Assert.assertNotNull;

/**
 *  Tests for the DatabaseUtils class
 */
public class DatabaseUtilsTest {

    @Test
    public void testGetConnection1() throws Exception {
        Connection connection = DatabaseUtils.getConnection();
        assertNotNull("verify that we can get a connection ok",connection);
    }

}
