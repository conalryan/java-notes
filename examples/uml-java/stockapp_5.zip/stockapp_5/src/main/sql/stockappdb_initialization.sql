/* delete tables if they exist already - ensuring a clean db*/
DROP TABLE IF EXISTS quotes CASCADE;

/** create a table to store stock quotes */
CREATE TABLE quotes(
  id INT NOT NULL AUTO_INCREMENT,
  symbol VARCHAR(4) NOT NULL,
  time DATETIME NOT NULL,
  price DECIMAL NOT NULL,
  PRIMARY KEY ( id )
);

INSERT INTO quotes (symbol,time,price) VALUES ('AAPL','2015-02-28 16:00:01','118.27');
INSERT INTO quotes (symbol,time,price) VALUES ('AAPL','2005-02-02 02:02:01','202.02');
INSERT INTO quotes (symbol,time,price) VALUES ('AAPL','1995-01-01 01:01:01','101.01');

INSERT INTO quotes (symbol,time,price) VALUES ('GOOG','2015-02-27 16:00:01','558.40');
INSERT INTO quotes (symbol,time,price) VALUES ('GOOG','2015-02-24 13:30:01','534.88');
INSERT INTO quotes (symbol,time,price) VALUES ('GOOG','2013-12-03 00:00:01','527.35');

INSERT INTO quotes (symbol,time,price) VALUES ('INTC','2015-02-27 16:00:01','33.25');
INSERT INTO quotes (symbol,time,price) VALUES ('INTC','2015-02-27 10:30:01','33.52');
INSERT INTO quotes (symbol,time,price) VALUES ('INTC','2015-02-26 12:00:01','33.60');