package com.conalryan.util;

import com.conalryan.model.Interval;
import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.util.Calendar;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class QueryUtilTest {

    private String symbol;
    private Calendar from;
    private Calendar until;
    private Interval interval;
    private String queryString;

    @Before
    public void setUp() throws Exception {
        symbol = "AAPL";
        from = Calendar.getInstance();
        from.set(2015, Calendar.FEBRUARY, 1);
        until = Calendar.getInstance();
        until.set(2015, Calendar.FEBRUARY, 28);
        interval = Interval.WEEKLY;

        queryString = "SELECT symbol, price, time FROM quotes WHERE symbol = 'AAPL' AND time >= '2015/02/01' AND time <= '2015/02/28' AND DAYOFWEEK(time) = 6 ORDER BY time";

    }

    @Test
    public void testCreateQuery() throws Exception {

        assertEquals("Query is correct", queryString,QueryUtil.createQuery(symbol, from, until, interval));
    }
}